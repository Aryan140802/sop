from django.urls import path, include

urlpatterns = [
    path('', include('sops.urls')),
    path('sop/', include('sops.urls')),  # ✅ includes app-level routing
]
